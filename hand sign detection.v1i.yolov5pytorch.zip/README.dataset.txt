# hand sign detection > 2025-03-20 4:40pm
https://universe.roboflow.com/ssachin23mitstudentmesacin/hand-sign-detection-0hpcq

Provided by a Roboflow user
License: CC BY 4.0

